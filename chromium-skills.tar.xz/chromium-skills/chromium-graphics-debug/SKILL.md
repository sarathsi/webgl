---
name: chromium-graphics-debug
description: >
  Expert knowledge for debugging and profiling the Chromium graphics and rendering stack.
  Use this skill whenever the user needs to: capture GPU traces, use RenderDoc, interpret
  chrome://tracing output for graphics/rendering, analyse UMA histograms for GPU metrics,
  run GPU benchmarks (Telemetry, MotionMark, WebXPRT), bisect a rendering regression,
  symbolize a GPU process crash, capture and replay an ANGLE frame, use gpu_benchmark,
  interpret about:gpu diagnostics, set up dEQP for conformance, use Perfetto for GPU
  profiling, configure GPU sandbox flags, use --use-cmd-decoder, or understand the
  GPU process watchdog. Also trigger for: "how do I trace this rendering bug",
  "what does this GPU crash signature mean", "how to bisect a WebGL perf regression",
  "RenderDoc with Chromium", or "reading a chrome://tracing GPU trace".
---

# Chromium Graphics Debugging & Performance Skill

You are a Chromium graphics debugging and performance expert and committer.

## Quick diagnostic checklist

When a graphics bug is reported, collect this information first:

```bash
# 1. GPU info:
chrome://gpu  → copy full text

# 2. Crash signature (if crash):
chrome://crashes → crash ID → look up in go/crash

# 3. Reproduce with minimal flags:
out/Debug/chrome --disable-gpu-sandbox --enable-logging \
  --v=1 --no-sandbox <url>

# 4. Check if software rendering reproduces:
out/Debug/chrome --use-angle=swiftshader <url>
# If yes: likely a GPU driver / hardware-specific bug

# 5. Check if a specific backend reproduces:
out/Debug/chrome --use-angle=gl <url>     # system OpenGL
out/Debug/chrome --use-angle=vulkan <url> # Vulkan via ANGLE
out/Debug/chrome --use-angle=metal <url>  # Metal (macOS)
```

## chrome://tracing for graphics

```bash
# Record a trace with GPU categories:
# 1. Open chrome://tracing
# 2. Click Record → select categories:
#    - blink, cc, gpu, renderer.scheduler, v8
#    - "disabled-by-default-cc.debug"
#    - "disabled-by-default-gpu.device"
#    - "disabled-by-default-skia.gpu"
# 3. Reproduce the issue → Stop

# Key trace events to look for:
# "CompositingInputsUpdater::update"   — pre-paint phase
# "LocalFrameView::UpdateLifecycle*"   — lifecycle phases
# "ScheduleCommit"                     — main→impl thread commit
# "BeginFrame" / "DrawAndSwap"         — compositor frame pipeline
# "GpuChannel::OnMessageReceived"      — GPU process message handling
# "FlushAndSubmit" / "GrFlush"         — Skia flush to GPU
```

### Reading GPU scheduling in traces
```
Main thread:  [BeginFrame]──[StyleRecalc]──[Layout]──[Paint]──[Commit]
                                                               │
Compositor:                                              [ActivatePendingTree]──[Draw]──[Swap]
                                                                                        │
GPU process:                                                             [ExecuteCommandBuffer]──[Present]
```

Jank appears as long gaps between `BeginFrame` and `Draw`, or `Draw` and `Swap`.

## RenderDoc with Chromium

RenderDoc captures GPU API calls for frame-by-frame inspection.

```bash
# Method 1: ANGLE frame capture (preferred for WebGL)
export ANGLE_CAPTURE_ENABLED=1
export ANGLE_CAPTURE_OUT_DIR=/tmp/angle_capture
export ANGLE_CAPTURE_FRAME_START=5
export ANGLE_CAPTURE_FRAME_END=10
out/Release/chrome <url>
# → /tmp/angle_capture/*.angledata files
# Open in RenderDoc via ANGLE trace loader

# Method 2: RenderDoc overlay (Vulkan)
# Launch RenderDoc UI → File → Launch Application
# Application: out/Release/chrome
# Command line: --use-angle=vulkan --no-sandbox <url>
# Capture key: F12

# Method 3: Built-in GPU capture (macOS Metal)
# Xcode → Debug → Capture GPU Frame
# Or: --gpu-startup-dialog to attach before GPU init
```

## Perfetto / about:tracing for GPU profiling

```bash
# Perfetto trace with GPU counters (Linux/Android):
tools/perf/record_wpr.py \
  --browser=release \
  --extra-browser-args="--enable-perfetto" \
  <story>

# GPU counter tracing (requires driver support):
--enable-features=PerfettoSystemTracing
# Counters: GPU freq, memory bandwidth, cache hit rates (vendor-specific)

# View in: https://ui.perfetto.dev
```

## GPU process crash analysis

```bash
# Symbolize a crash stack (Linux):
tools/valgrind/asan/asan_symbolize.py < crash.txt

# GPU process crash categories:
# 1. COMMAND_BUFFER_ENTRY_POINT_* → bad GL state machine in service
# 2. ANGLE/Skia assert → driver returned unexpected value
# 3. OOM (GL_OUT_OF_MEMORY) → texture allocation failed
# 4. Watchdog timeout → GPU hung (shader loop, long draw call)

# Force GPU process in-process for easier debugging:
--in-process-gpu  # WARNING: security disabled, debug only

# Attach debugger to GPU process:
--gpu-startup-dialog  # Shows PID to attach to before GPU init
```

## Regression bisection

```bash
# Graphics-specific bisect workflow:

# 1. Identify range from bug report or Findit
# 2. Use bisect script:
tools/bisect_builds.py \
  -a linux64 \
  -g <good_revision> \
  -b <bad_revision> \
  --use-local-cache

# 3. For performance regressions, use Pinpoint:
# go/pinpoint → New Job → compare two commits

# 4. For layout/pixel regressions:
# Run layout tests on both revisions:
third_party/blink/tools/run_web_tests.py \
  --revision=<rev> \
  virtual/gpu/ \
  --results-directory=/tmp/test-results
```

## Key metrics & UMA histograms

```bash
# Graphics-related histograms to watch:
# Compositing.Display.DrawToSwapUs           — frame latency
# GPU.Rasterization.Raster.MSPerTile         — OOP raster tile time
# Graphics.Smoothness.PercentDroppedFrames*  — jank rate
# GPU.SharedImage.TotalSizeInMB              — SharedImage memory
# GPU.WatchdogThread.Timeout.*               — GPU hang events

# View in:
# chrome://histograms/<name>
# Or: go/uma-guide
```

## Common debugging flags reference

```bash
# Rendering debug overlays:
--show-paint-rects            # Red flash on paint invalidation
--show-property-changed-rects # Blue on property tree changes
--show-composited-layer-borders # Layer boundaries
--show-fps-counter            # FPS overlay

# Compositor:
--enable-threaded-compositing  # (default on)
--disable-threaded-compositing # Force single-threaded (debugging)
--num-raster-threads=1         # Force single raster thread

# GPU process:
--disable-gpu-sandbox          # Debug: no GPU process sandbox
--disable-gpu-watchdog         # Debug: no GPU hang detection
--in-process-gpu               # Debug: GPU in renderer process
--enable-gpu-benchmarking      # Enable chrome.gpuBenchmarking API

# Logging:
--enable-logging --v=1
--vmodule=compositor*=3,cc*=2,gpu_channel*=2

# Feature flags:
--enable-features=X,Y,Z
--disable-features=X,Y,Z
```

## dEQP conformance suite setup

```bash
# Build GLES3 deqp:
autoninja -C out/Debug dEQP-GLES3

# Run specific test group:
out/Debug/dEQP-GLES3 \
  --deqp-case="dEQP-GLES3.functional.shaders.builtin_functions.*" \
  --deqp-gl-config-name=rgba8888d24s8ms0 \
  --deqp-watchdog=disable \
  --deqp-log-filename=/tmp/dEQP-results.qpa

# Parse results:
python third_party/angle/scripts/parse_dEQP_output.py \
  /tmp/dEQP-results.qpa

# Run WebGPU CTS:
out/Default/chrome \
  --enable-unsafe-webgpu \
  "third_party/dawn/webgpu-cts/tests/?q=webgpu:api,operation,texture_view,*"
```

## Bug filing template

When filing a Chromium graphics bug, always include:
1. `chrome://gpu` dump
2. OS + driver version
3. Reproduction URL or steps
4. `--enable-logging` output
5. Whether SwiftShader (`--use-angle=swiftshader`) reproduces
6. Component: `Internals>GPU`, `Internals>Blink>Paint`, `Internals>Compositing`, etc.
