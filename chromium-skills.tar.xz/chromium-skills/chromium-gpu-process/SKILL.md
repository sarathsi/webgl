---
name: chromium-gpu-process
description: >
  Expert knowledge for the Chromium GPU process, GPU command buffer IPC, SharedImage system,
  GpuMemoryBuffer, sync tokens, mailboxes, and OOP rasterization. Use this skill whenever the
  user mentions: GpuChannel, CommandBufferStub, CommandBufferProxy, GpuCommandBufferMsg,
  SharedImageFactory, SharedImageRepresentation, GpuMemoryBufferFactory, SyncToken, Mailbox,
  OOP-raster, SkiaRenderer, DisplayCompositor, viz::CompositorFrame, viz::Surface,
  gpu process crash, GPU watchdog, COMMAND_BUFFER_ENTRY_POINT, GLES2Interface,
  RasterInterface, WebGPUInterface, or cross-process texture sharing bugs.
  Also trigger for "GPU process keeps crashing", "lost context after tab switch",
  "SharedImage allocation failure", or "sync token not signalled".
---

# Chromium GPU Process & Command Buffer Skill

You are a Chromium GPU process and command buffer expert and committer.

## Architecture overview

```
Renderer process                    GPU process
─────────────────                   ──────────────────────────────
CommandBufferProxy  ──── IPC ────→  CommandBufferStub
  (client side)       Mojo pipe       (service side, per context)
  GLES2Implementation              GLES2DecoderImpl
  RasterImplementation             RasterDecoderImpl
  WebGPUImplementation             DawnServiceAdapter

SharedImageInterface  ── IPC ──→  SharedImageFactory
  ClientSharedImage                SharedImageBacking
  (mailbox handle)                 (actual GPU memory)
                                   Representations:
                                     GLTexture, SkSurface, Dawn texture
```

## Key source locations

| Component | Path |
|---|---|
| GPU process main | `content/gpu/` |
| Command buffer client | `gpu/command_buffer/client/` |
| Command buffer service | `gpu/command_buffer/service/` |
| SharedImage | `gpu/command_buffer/service/shared_image/` |
| GpuChannel | `gpu/ipc/service/gpu_channel.cc` |
| Viz (display compositor) | `components/viz/service/display/` |
| SkiaRenderer | `components/viz/service/display/skia_renderer.cc` |

## SharedImage system

SharedImages are the primary cross-process texture sharing mechanism (replacing mailboxes directly).

```cpp
// Creating a SharedImage (renderer side):
auto client_si = shared_image_interface->CreateSharedImage(
    {SinglePlaneFormat::kRGBA_8888, size, color_space,
     kTopLeft_GrSurfaceOrigin, kPremul_SkAlphaType,
     SHARED_IMAGE_USAGE_GLES2 | SHARED_IMAGE_USAGE_DISPLAY_READ},
    gpu::kNullSurfaceHandle);
// client_si->mailbox() is the cross-process handle

// GPU process creates backing via SharedImageFactory::CreateSharedImage()
// Backings: AngleVulkanImageBacking, GLTextureImageBacking, DXGISwapChainImageBacking...
```

### Debug SharedImage issues
```bash
# List active SharedImages:
# chrome://gpu → "SharedImage Info" section (Debug builds)

# Enable verbose SharedImage logging:
--enable-logging --vmodule=shared_image*=3,gpu_channel*=2

# Check backing type selection:
# gpu/command_buffer/service/shared_image/shared_image_factory.cc
# SharedImageFactory::GetBackingForFormat()
```

## Sync tokens & ordering

```cpp
// SyncToken = (namespace, command_buffer_id, release_count)
// Ensures ordering between command buffers

// Pattern: produce on ContextA, consume on ContextB
SyncToken sync_token;
gl_context_a->GenSyncTokenCHROMIUM(sync_token.GetData());

// ContextB must wait before accessing the shared resource:
gl_context_b->WaitSyncTokenCHROMIUM(sync_token.GetConstData());
```

Common bug: SyncToken not waited → GPU reads stale data silently.
Check: `gpu/command_buffer/service/sync_point_manager.cc`

## GPU watchdog

The GPU watchdog kills the GPU process if a command takes >8s (configurable).

```bash
# Disable for debugging (never in production):
--disable-gpu-watchdog

# Increase timeout:
--gpu-watchdog-timeout=60

# Check watchdog triggers in:
# gpu/ipc/service/gpu_watchdog_thread.cc
```

## OOP rasterization

Out-of-process raster: Renderer records `cc::PaintRecord` → sends to GPU process →
GPU process rasterizes via Skia/Ganesh on the GPU.

```bash
# Force OOP raster on/off:
--enable-features=DefaultEnableOopRasterization
--disable-features=OopRasterization

# Check if active: chrome://gpu → "OOP Rasterization" row

# Key path:
# RasterDecoder::DoRasterCHROMIUM()  [gpu/command_buffer/service/raster_decoder.cc]
# → SkiaImageFromSharedImage()
# → SkCanvas::drawPicture()
```

## Common bug patterns

### GPU process crash on context creation
1. Check `chrome://gpu` for blacklisted features
2. Check driver version in `GpuFeatureInfo`
3. Enable: `--enable-logging --vmodule=gpu_channel*=3,command_buffer*=3`
4. Look for `GL_OUT_OF_MEMORY` or driver validation errors

### "Context was lost" in renderer
```cpp
// CommandBufferProxy::OnGpuStateError() is called
// → signals all waiters with LOST_CONTEXT
// Root causes:
//   - GPU process crash (check chrome://crashes)
//   - Watchdog timeout (check GPU thread stall)
//   - GLES2DecoderImpl detected invalid state
```

### SharedImage allocation failure
```cpp
// SharedImageFactory::CreateSharedImage() returns null
// Check:
//   1. gpu::GpuMemoryBufferFactory backing type support for this format+usage
//   2. SharedImageUsage flags compatibility with backing
//   3. GPU memory pressure (GpuMemoryManager)
```

### Sync token never signalled
- Source: `SyncPointClientState::ReleaseFenceSync()` never called
- Usually means GPU command buffer stalled or context lost before the release
- Check: `SyncPointManager::GetSyncTokenStatus()` in a debug build

## Build & test
```bash
autoninja -C out/Debug gpu_unittests
out/Debug/gpu_unittests --gtest_filter="*SharedImage*"
out/Debug/gpu_unittests --gtest_filter="*CommandBuffer*"
out/Debug/gpu_unittests --gtest_filter="*SyncPoint*"

# Integration:
autoninja -C out/Debug content_browsertests
out/Debug/content_browsertests --gtest_filter="*GPU*"
```
