---
name: angle-dawn-backends
description: >
  Expert knowledge for ANGLE (Almost Native Graphics Layer Engine) and Dawn (WebGPU
  implementation), the GPU backend translation layers in Chromium. Use this skill whenever
  the user mentions: ANGLE, GLESv2, libANGLE, EGL, angle::Renderer, angle::ContextGL,
  angle::ContextVk, angle::ContextMtl, angle::ContextD3D11, HLSL, ESSL, shader translator,
  gl_FragCoord workaround, SwiftShader, Dawn, dawn::native, wgpu, WGPUDevice, DawnVulkan,
  DawnMetal, DawnD3D12, DawnD3D11, adapter selection, Tint, SPIRV-Cross, Vulkan validation
  layers, Metal debugging, D3D debug layer, ANGLE workarounds / features, ANGLE unit tests,
  angle_end2end_tests, dEQP-GLES, or any native backend crash or conformance failure.
  Also trigger for "ANGLE validation error", "shader doesn't compile on ANGLE Metal",
  "Vulkan validation layer warning", or "ANGLE feature flag".
---

# ANGLE & Dawn Backends Skill

You are an ANGLE and Dawn expert and Chromium committer, covering GPU backend translation
from GL ES / WebGPU down to native APIs.

## ANGLE architecture

```
Application (WebGL / GLES2)
  → libEGL (EGL surface/context management)
  → libGLESv2 (GLES2/3 entry points)
  → angle::Context (validates, dispatches)
  → angle::Renderer (abstract backend interface)
       ├─ RendererGL   → system OpenGL/ES (passthrough or translation)
       ├─ RendererVk   → Vulkan (primary on Linux/Android/Chrome OS)
       ├─ RendererMtl  → Metal (macOS/iOS)
       ├─ RendererD3D11 → D3D11 (Windows)
       └─ RendererWgpu → WebGPU/Dawn (experimental)
  → Native GPU API
```

## Key source locations

| Component | Path |
|---|---|
| ANGLE root | `third_party/angle/` |
| ANGLE core | `third_party/angle/src/libANGLE/` |
| Vulkan backend | `third_party/angle/src/libANGLE/renderer/vulkan/` |
| Metal backend | `third_party/angle/src/libANGLE/renderer/metal/` |
| D3D11 backend | `third_party/angle/src/libANGLE/renderer/d3d/d3d11/` |
| Shader translator | `third_party/angle/src/compiler/translator/` |
| SwiftShader | `third_party/swiftshader/` |
| Dawn root | `third_party/dawn/` |
| Dawn backends | `third_party/dawn/src/dawn/native/` |
| Tint (WGSL) | `third_party/dawn/src/tint/` |

## ANGLE feature flags / workarounds

ANGLE has per-driver workarounds for GPU bugs. These are critical to understand for
platform-specific failures.

```cpp
// Feature flags live in:
// third_party/angle/src/libANGLE/renderer/vulkan/vk_caps_utils.cpp
// third_party/angle/src/libANGLE/renderer/gl/WorkaroundsGL.cpp

// To list active features at runtime:
// chrome://gpu → "ANGLEFeatures" section

// Enable/disable from command line:
--use-angle=vulkan
--use-angle=gl
--use-angle=metal
--use-angle=d3d11
--use-angle=swiftshader

// Force specific workaround:
--enable-angle-features=slowDownMonolithicPipelineCreationForTesting
--disable-angle-features=supportsExternalMemoryFd
```

### Adding a new workaround
1. Add entry in `third_party/angle/src/libANGLE/renderer/<backend>/FeatureFlags.h`
2. Implement detection in `InitializeFeatures()` (check vendor ID, device ID, driver version)
3. Guard the workaround code with `features.myWorkaround.enabled`
4. Add test to `angle_end2end_tests` with `ANGLE_SKIP_TEST_IF(!IsFeatureEnabled(...))`

## ANGLE shader translator

The GLSL ES → HLSL/MSL/GLSL/SPIR-V translator is the core of cross-platform shader compatibility.

```bash
# Run the standalone translator:
out/Debug/angle_shader_translator \
  --type=fragment \
  --output=hlsl \
  input.glsl

# Common translation issues:
# - gl_FragCoord: y-flip depending on backend
# - Precision qualifiers: mediump vs highp differences
# - Loop unrolling: D3D11 requires bounded loops
# - Struct array indexing: Metal/MSL constraints
```

### Debugging a shader compile failure
```bash
# Enable ANGLE translator logging:
export ANGLE_DEBUG_LAYERS=1  # (some platforms)
--enable-logging --vmodule=ShaderGL=4,CompiledShaderState=3

# Capture ANGLE frame (replay a bug):
# Set: ANGLE_CAPTURE_ENABLED=1
#      ANGLE_CAPTURE_OUT_DIR=/tmp/angle_capture
# Then replay with:
out/Debug/angle_trace_tests --gtest_filter="*YourCapture*"
```

## Dawn architecture

```
WebGPU API (JS / C++)
  → Dawn wire protocol (client ↔ server)
  → dawn::native::Adapter → dawn::native::Device
  → Backend implementations:
       ├─ VulkanBackend  (Linux, ChromeOS, Android)
       ├─ MetalBackend   (macOS, iOS)
       ├─ D3D12Backend   (Windows)
       ├─ D3D11Backend   (Windows fallback)
       └─ OpenGLBackend  (Linux fallback)
  → Tint (WGSL → SPIR-V / MSL / HLSL / GLSL)
```

## Dawn debugging

### Enable validation layers
```cpp
// In Dawn adapter options:
WGPUDawnTogglesDescriptor toggles{};
const char* enabled[] = {"use_dxc", "dump_shaders", "disable_robustness"};
toggles.enabledToggles = enabled;
toggles.enabledToggleCount = std::size(enabled);

// Common useful toggles:
// "skip_validation"           — skip Dawn validation (for perf testing)
// "dump_shaders"              — print translated shaders to stdout
// "use_dxc"                   — use DXC instead of FXC on D3D12
// "disable_lazy_clear"        — helps catch uninitialized texture reads
// "record_detailed_timing"    — timestamp queries on every pass
```

### Dawn toggle reference
```bash
# List all available toggles:
out/Debug/dawn_info_tests --list-toggles

# Force toggle via Chromium:
--enable-dawn-features=dump_shaders,use_dxc
--disable-dawn-features=use_dxc
```

### Vulkan validation layers (Dawn + ANGLE)
```bash
# Enable via environment variable:
export VK_INSTANCE_LAYERS=VK_LAYER_KHRONOS_validation
export VK_LAYER_SETTINGS_PATH=/path/to/vk_layer_settings.txt

# Or via Chromium switch:
--enable-features=VulkanValidationLayers

# Check validation output in stderr / --enable-logging output
```

## ANGLE end-to-end tests (dEQP)
```bash
# Build:
autoninja -C out/Debug angle_end2end_tests dEQP-GLES2 dEQP-GLES3

# Run ANGLE's own conformance tests:
out/Debug/angle_end2end_tests \
  --gtest_filter="*TextureTest*" \
  --use-angle=vulkan

# Run dEQP suite:
out/Debug/dEQP-GLES3 \
  --deqp-case="dEQP-GLES3.functional.texture.*" \
  --deqp-gl-config-name=rgba8888d24s8ms0 \
  --deqp-watchdog=disable

# Dawn tests:
out/Debug/dawn_end2end_tests --gtest_filter="*Texture*"
out/Debug/dawn_end2end_tests --backend=vulkan --gtest_filter="*Compute*"
```

## Common bug patterns

### Shader compiles on GL but fails on Metal/D3D
- Check precision qualifiers: `highp` required for some ops on Metal
- Check loop bounds: D3D11/HLSL requires statically-bounded loops
- Check struct packing: HLSL uses different alignment rules (use explicit `packoffset`)
- File: `third_party/angle/src/compiler/translator/TranslatorHLSL.cpp`

### Vulkan validation error in ANGLE
- Usually: missing pipeline barrier, incorrect image layout transition
- Check: `third_party/angle/src/libANGLE/renderer/vulkan/vk_utils.cpp`
- Enable: `--enable-features=VulkanValidationLayers` in Chromium

### Dawn device lost on D3D12
- Check for DXGI device removed: `DXGI_ERROR_DEVICE_REMOVED`
- Get removal reason: `ID3D12Device::GetDeviceRemovedReason()`
- Often a TDR (Timeout Detection Recovery) — check GPU workload duration
- Enable: `--enable-dawn-features=use_dxc` to get better D3D12 debug info

### SwiftShader fallback unexpectedly used
- Check: `chrome://gpu` → "GL_RENDERER" contains "Google SwiftShader"
- Cause: GPU process blocklist, driver crash, missing Vulkan support
- Force hardware: `--use-angle=gl` (or `vulkan`/`metal`)
