---
name: webgl-webgpu-api
description: >
  Expert knowledge for the WebGL 1/2 and WebGPU API implementations in Chromium (Blink side).
  Use this skill whenever the user mentions: WebGLRenderingContext, WebGL2RenderingContext,
  GPUDevice, GPUCommandEncoder, GPURenderPassEncoder, GPUComputePassEncoder, GPUBuffer,
  GPUTexture, GPUSampler, GPUBindGroup, GPUShaderModule, WGSL, GLSL, shader compilation,
  context loss, OES extensions, WebGL conformance (CTS), WebGPU CTS, GPUAdapter,
  requestAdapterInfo, WebGPU error scopes, SPIR-V, Tint (WGSL compiler), or any WebGL/WebGPU
  rendering bug, crash, or spec compliance issue. Also trigger for "WebGL black screen",
  "GPUDevice lost", "invalid operation", shader linking failures, or texture format issues.
---

# WebGL / WebGPU API Skill

You are a Chromium WebGL and WebGPU implementation expert and committer. This covers the
Blink-side API objects, validation, and the bridge to the GPU process.

## Architecture overview

```
JavaScript (WebGL/WebGPU calls)
  → Blink WebGL/WebGPU bindings (IDL → C++)
  → WebGLRenderingContextBase / GPU (Dawn wire client)
  → Command serialization (gpu::CommandBuffer client)
  → IPC to GPU process
  → GPU process: CommandBufferStub (WebGL) / Dawn wire server (WebGPU)
  → ANGLE (for WebGL) / Dawn (for WebGPU)
  → Native GPU API (GL ES / Vulkan / Metal / D3D12)
```

## Key source locations

| Component | Path |
|---|---|
| WebGL context | `third_party/blink/renderer/modules/webgl/` |
| WebGPU bindings | `third_party/blink/renderer/modules/webgpu/` |
| Dawn wire client | `third_party/dawn/src/dawn/wire/client/` |
| GPU command buffer client | `gpu/command_buffer/client/` |
| WebGL GPU-side service | `gpu/command_buffer/service/gles2_cmd_*` |
| Tint (WGSL compiler) | `third_party/dawn/src/tint/` |

## WebGL debugging

### Context loss
```cpp
// Blink side: WebGLRenderingContextBase::ForceLoseContext()
// Triggers: WEBGL_lose_context extension, GPU process crash, OOM

// Debug steps:
// 1. Check chrome://gpu for GPU process status
// 2. Enable: --enable-logging --v=1 --vmodule=webgl*=3
// 3. Check WebGL context attributes: failIfMajorPerformanceCaveat
// 4. Reproduce with: --disable-gpu-watchdog for timeout exclusion
```

### Shader compilation failures
```bash
# ANGLE shader translator logs:
--enable-logging --vmodule=shader_translator=3

# Check ANGLE's intermediate representation:
# Set ANGLE_DUMP_SHADERS=1 env var (debug builds)

# Key file: gpu/command_buffer/service/shader_translator.cc
# ANGLE translator: third_party/angle/src/compiler/translator/
```

### Texture format / extension issues
```cpp
// Extension support is per-backend in ANGLE:
// third_party/angle/src/libANGLE/renderer/gl/FunctionsGL.cpp
// third_party/angle/src/libANGLE/Caps.cpp (WebGLExtension caps)

// In Blink: WebGLRenderingContextBase::GetExtension()
// Extensions guarded by: RuntimeEnabledFeatures, gpu::GpuFeatureInfo
```

### WebGL conformance test failures
```bash
# Run CTS:
python third_party/webgl/src/sdk/tests/webgl-conformance-tests.py \
  --browser=out/Default/chrome \
  --version=2.0.0

# For a specific test:
out/Default/chrome \
  "third_party/webgl/src/sdk/tests/conformance2/textures/misc/tex-base-level-bug.html"
```

## WebGPU debugging

### GPUDevice lost
```javascript
// Always listen for device loss:
device.lost.then(info => {
  console.error('WebGPU device lost:', info.reason, info.message);
});

// Common causes:
// - GPU process crash → check chrome://gpu
// - Dawn validation error (promotion to device loss)
// - Timeout (long compute shader)
```

### Dawn validation errors / error scopes
```javascript
// Wrap suspicious operations:
device.pushErrorScope('validation');
// ... operation ...
device.popErrorScope().then(err => {
  if (err) console.error('Validation:', err.message);
});
```

### WGSL shader errors (Tint)
```bash
# Run Tint directly on a .wgsl file:
out/Default/tint --format=msl input.wgsl
out/Default/tint --format=spv input.wgsl
out/Default/tint --format=hlsl input.wgsl

# Validate only:
out/Default/tint --validate input.wgsl

# Key Tint source: third_party/dawn/src/tint/lang/wgsl/
```

### WebGPU CTS
```bash
# Run WebGPU CTS via Telemetry:
tools/run_tests.py --target=Release gpu \
  -- --test-machine-name=chromium-webgpu \
     --extra-browser-args="--enable-dawn-features=..."

# Or directly:
out/Default/chrome \
  "third_party/dawn/webgpu-cts/tests/?q=webgpu:shader,execution,*"
```

## Common bug patterns

### Black canvas / invisible output
1. Check context creation success: `canvas.getContext('webgl')` → null?
2. Check software rendering fallback: `chrome://gpu` → "WebGL" row
3. Verify draw calls reached GPU: Use RenderDoc / ANGLE frame capture
4. Check for silent WebGL errors: `gl.getError()` after each call

### Performance: draw call overhead
- Check `gl.drawArrays` / `gl.drawElements` call count via chrome://tracing
- Use `WEBGL_draw_buffers`, `ANGLE_instanced_arrays`, `OES_vertex_array_object`
- For WebGPU: use render bundles to amortize recording cost

### SharedArrayBuffer / cross-origin isolation
WebGL2 `readPixels` into SAB requires COOP/COEP headers:
```
Cross-Origin-Opener-Policy: same-origin
Cross-Origin-Embedder-Policy: require-corp
```

## Build & test
```bash
# Build:
autoninja -C out/Debug webgl_conformance_tests

# Unit tests:
out/Debug/gpu_unittests --gtest_filter="*WebGL*"
out/Debug/gpu_unittests --gtest_filter="*Dawn*"

# Dawn unit tests:
out/Debug/dawn_unittests
out/Debug/dawn_end2end_tests
```
