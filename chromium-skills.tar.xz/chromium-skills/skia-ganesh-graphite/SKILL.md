---
name: skia-ganesh-graphite
description: >
  Expert knowledge for Skia graphics library as used in Chromium — both the legacy Ganesh
  (OpenGL/Vulkan GPU backend) and the new Graphite (Dawn/Vulkan, explicit GPU API) architecture.
  Use this skill whenever the user mentions: SkCanvas, SkSurface, SkImage, SkPaint, SkPath,
  SkShader, SkColorFilter, GrContext, GrDirectContext, GrRecordingContext, GrBackendTexture,
  SkGpuDevice, Graphite, skgpu::graphite::Recorder, skgpu::graphite::Context, SkSL,
  SkRuntimeEffect, Precompile, GrProgramInfo, SkPicture, SkDeferredDisplayList,
  Skia gold (pixel tests), sk_sp, SkBitmap, SkPixmap, SkColorSpace, color gamut,
  or any Skia rendering artifact, pixel mismatch, or GPU backend crash.
  Also trigger for "skia gold failure", "SkSL shader error", "Graphite migration", or
  "how to add a new SkSL effect".
---

# Skia Ganesh & Graphite Skill

You are a Skia graphics expert and Chromium committer, covering both Ganesh (legacy) and
Graphite (new explicit-GPU architecture).

## Architecture comparison

```
┌─────────────────────────────────────────────────────────────┐
│  Ganesh (current)              Graphite (new, Chromium 120+) │
│  ─────────────────             ────────────────────────────  │
│  GrDirectContext               skgpu::graphite::Context       │
│  GrRecordingContext            skgpu::graphite::Recorder      │
│  GrRenderTargetContext         skgpu::graphite::Surface       │
│  GrGpu (abstract backend)      skgpu::graphite::QueueManager │
│  GrGLGpu / GrVkGpu / GrMtlGpu Dawn backend (GrDawnGpu gone) │
│                                                              │
│  Command submission: lazy,     Explicit recording → submit   │
│  driver-managed batching       Task graph, explicit barriers  │
└─────────────────────────────────────────────────────────────┘
```

## Key source locations

| Component | Path |
|---|---|
| Skia root | `third_party/skia/` |
| Ganesh | `third_party/skia/src/gpu/ganesh/` |
| Graphite | `third_party/skia/src/gpu/graphite/` |
| SkSL compiler | `third_party/skia/src/sksl/` |
| Chromium Skia integration | `skia/` (Chromium-side wrappers) |
| OOP-raster uses Skia via | `gpu/command_buffer/service/raster_decoder.cc` |

## Ganesh usage patterns in Chromium

```cpp
// Creating a GrDirectContext (GL backend example):
auto context = GrDirectContext::MakeGL(gl_interface, gr_options);

// Creating an SkSurface on a GrBackendTexture:
GrBackendTexture backend_tex = context->createBackendTexture(
    width, height, kRGBA_8888_SkColorType,
    GrMipmapped::kNo, GrRenderable::kYes);
auto surface = SkSurface::MakeFromBackendTexture(
    context.get(), backend_tex,
    kTopLeft_GrSurfaceOrigin, 1 /*sampleCnt*/,
    kRGBA_8888_SkColorType, nullptr, nullptr);

// Drawing:
SkCanvas* canvas = surface->getCanvas();
canvas->drawRect(rect, paint);
surface->flushAndSubmit();  // Important! Ganesh batches internally.
```

### Common Ganesh pitfalls
- **Forgetting `flushAndSubmit()`** — draws are deferred; nothing reaches the GPU until flush.
- **Wrong surface origin** — `kBottomLeft_GrSurfaceOrigin` (GL default) vs `kTopLeft` (Vulkan/Metal/DX). Mismatches cause vertical flips.
- **GrContext abandoned** — after GPU context loss, `GrDirectContext::isContextLost()` is true; all subsequent ops are no-ops silently.
- **Texture vs render target** — `GrRenderable::kNo` textures cannot be drawn to; results in silent black.

## Graphite usage patterns

```cpp
// Graphite context creation (Dawn backend):
skgpu::graphite::DawnBackendContext dawn_ctx;
dawn_ctx.fDevice = wgpu_device;
dawn_ctx.fQueue  = wgpu_queue;
auto context = skgpu::graphite::ContextFactory::MakeDawn(dawn_ctx, options);

// Recording (analogous to a GPU command encoder):
auto recorder = context->makeRecorder();
auto surface  = SkSurface::MakeGraphite(recorder.get(), image_info);
auto* canvas  = surface->getCanvas();
canvas->drawCircle({100, 100}, 50, paint);

// Submitting:
std::unique_ptr<skgpu::graphite::Recording> recording = recorder->snap();
context->insertRecording({recording.get()});
context->submit(skgpu::graphite::SyncToCpu::kYes);
```

### Graphite-specific gotchas
- `Recorder` is NOT thread-safe — one recorder per thread.
- `Recording` can be replayed (insertRecording multiple times) — mutations to SkImages after snap() are NOT reflected.
- **Precompile** is mandatory for production — avoids stalls from runtime pipeline compilation:
  ```cpp
  skgpu::graphite::PaintOptions paint_options;
  paint_options.setShaders({SkShaders::Color(...)});
  skgpu::graphite::Precompile(context.get(), paint_options, draw_types);
  ```

## SkSL & SkRuntimeEffect

```cpp
// Custom shader via SkRuntimeEffect:
auto [effect, err] = SkRuntimeEffect::MakeForShader(SkString(R"(
  uniform float2 resolution;
  half4 main(float2 coord) {
    float2 uv = coord / resolution;
    return half4(uv.x, uv.y, 0.5, 1.0);
  }
)"));
if (!effect) { LOG(ERROR) << err.c_str(); }

SkRuntimeShaderBuilder builder(effect);
builder.uniform("resolution") = SkV2{(float)width, (float)height};
auto shader = builder.makeShader();

SkPaint paint;
paint.setShader(shader);
canvas->drawRect(bounds, paint);
```

### SkSL debugging
```bash
# Dump generated GLSL/MSL/WGSL from SkSL:
# Set env: SK_GL_PROGRAM_CACHE_HITS_AND_MISSES=1

# Run skslc tool:
out/Debug/skslc --glsl input.sksl
out/Debug/skslc --wgsl input.sksl

# SkSL fuzzer:
out/Debug/sksl_fuzz --seed=0xdeadbeef
```

## Pixel testing (Skia Gold)

Chromium uses Skia Gold for pixel-exact regression detection.

```bash
# Run a Gold test locally:
out/Debug/browser_tests \
  --gtest_filter="SkiaGoldPixelDiffTest*" \
  --skia-gold-local-png-write-directory=/tmp/gold

# Upload to Gold triage:
# Automatic on CI; locally use:
python tools/skia_gold_common/skia_gold_session_manager.py --help
```

## Debugging rendering artifacts

### Ganesh: unexpected color/alpha
1. Check `SkColorSpace` — is the surface tagged? Is the source image tagged?
2. Check `SkBlendMode` on SkPaint
3. Use `GrAuditTrail` (debug builds): `context->auditTrail()`

### Graphite: draw not appearing
1. Did you call `recorder->snap()` and `context->insertRecording()`?
2. Check `context->submit()` return value — false means GPU error
3. Verify `SkSurface::MakeGraphite()` succeeded (check for null)

### Both: performance regression
```bash
# Run Skia nanobench:
out/Release/nanobench --config gles \
  --match ".*SkPath.*" \
  --outResultsFile /tmp/bench.json

# Flame chart via chrome://tracing with "skia" category
```

## Build & test
```bash
# Skia unit tests (run from Chromium):
autoninja -C out/Debug skia_unittests
out/Debug/skia_unittests --gtest_filter="*Graphite*"
out/Debug/skia_unittests --gtest_filter="*GrContext*"
out/Debug/skia_unittests --gtest_filter="*SkSL*"

# DM (Skia's test harness):
out/Debug/dm --src gm --config gles --match aaclip
```
