---
name: blink-rendering
description: >
  Expert knowledge for understanding, debugging, and fixing bugs in the Blink rendering pipeline —
  from DOM construction through Style, Layout, Paint, and Compositing (CC layer tree) to the
  Renderer → GPU handoff. Use this skill whenever the user mentions: RenderingNG, LayoutObject,
  PaintLayer, compositing, layer squashing, rasterization, invalidation, dirty bits, cc::Layer,
  viz::CompositorFrame, display lists, paint chunks, property trees (transform/clip/effect/scroll),
  BlinkGenPropertyTrees, or any Blink rendering regression or crash. Also trigger for topics like
  "why is this element not composited", "hit testing", "scrolling jank", "paint invalidation loop",
  or "how does Blink turn HTML into pixels".
---

# Blink Rendering Pipeline Skill

You are a Chromium Blink rendering expert and committer. This skill covers the full path from
HTML/CSS parsing to the CompositorFrame handed off to the GPU process.

## Pipeline overview (RenderingNG)

```
HTML/CSS parsing
  → DOM tree + CSSOM
  → Style (ComputedStyle, StyleResolver)
  → Layout (LayoutObject tree, LayoutNG)
  → Pre-paint (property trees: TransformTree, ClipTree, EffectTree, ScrollTree)
  → Paint (DisplayItemList, PaintChunk, PaintArtifact)
  → Compositing assignment (PaintLayerCompositor / CompositingReasonFinder)
  → Layerization (cc::Layer, cc::PictureLayer)
  → Rasterization (OOP-raster via GpuRasterizationPolicy or software)
  → cc::LayerTreeHost → cc::LayerTreeHostImpl (impl thread)
  → Tile management + GPU raster
  → viz::CompositorFrame → Display Compositor (Viz)
  → Final draw to screen
```

## Key source locations

| Component | Path |
|---|---|
| Style | `third_party/blink/renderer/core/css/` |
| Layout | `third_party/blink/renderer/core/layout/` |
| Paint | `third_party/blink/renderer/core/paint/` |
| Compositing | `third_party/blink/renderer/core/paint/compositing/` |
| CC (compositor) | `cc/` |
| Viz | `components/viz/` |
| Property trees | `cc/trees/` (TransformNode, ClipNode, EffectNode, ScrollNode) |

## Debugging recipes

### Compositing reasons
```bash
# Enable compositing reasons in DevTools:
# DevTools → Layers panel → hover a layer → see "Compositing Reasons"

# In code: check CompositingReasonFinder::CompositingReasonsForPaint()
# File: third_party/blink/renderer/core/paint/compositing/compositing_reason_finder.cc
```

### Paint invalidation tracing
```bash
# Enable via command line:
--enable-logging --v=1 --vmodule=paint_invalidator=3

# Or add trace events:
about:tracing → record → "blink" category
# Look for: "PaintInvalidation", "LocalFrameView::UpdateLifecyclePhases"
```

### Layout debugging
```bash
# LayoutNG inspector:
--enable-blink-features=LayoutNG

# Key classes to understand:
# LayoutBlockFlow, LayoutInline, NGBlockNode, NGLayoutResult
# NGConstraintSpace → NGFragmentainerIterator (for multicol/pagination)
```

### Property tree debugging
```bash
# In content_shell or chrome:
--show-property-changed-rects
--show-paint-rects
--show-composited-layer-borders

# Programmatic: cc::LayerTreeDebugState
```

## Common bug patterns

### Compositor layer explosion
Cause: Too many elements promoting to their own compositor layer.
Check: `CompositingReasonFinder`, `PaintLayerCompositor::UpdateCompositingLayers()`
Fix: Review `will-change`, `transform`, `opacity` usage. Consider layer squashing.

### Incorrect stacking context / z-index
Cause: Missed stacking context creation in `PaintLayerStackingNode`.
File: `third_party/blink/renderer/core/paint/paint_layer_stacking_node.cc`

### Paint invalidation not triggering
Cause: Missing call to `SetNeedsPaintPropertyUpdate()` or `SetShouldDoFullPaintInvalidation()`.
Check `PaintInvalidator::InvalidatePaint()` call chain.

### Scroll-linked animation jank
Cause: Scroll timeline running on main thread instead of compositor.
Check: `ScrollSnap`, `AnimationWorklet`, `cc::ScrollTimeline`

### Property tree mismatch (DCHECK failures)
Common in: `cc/trees/property_tree.cc`, `DrawProperty` computation.
Debug: Enable `--enable-features=PaintHoldingForIframes` trace + compare trees.

## RenderingNG lifecycle phases

```cpp
// LocalFrameView::UpdateLifecyclePhases() — the master sequencer
// Phases (kUninitialized → kPaintClean):
kStyleClean        // After StyleResolver
kLayoutClean       // After Layout
kAccessibilityClean
kPrePaintClean     // After property tree build
kPaintClean        // After DisplayItemList creation
```

Always check which lifecycle phase an access occurs in — accessing layout geometry
before `kLayoutClean` causes silent bugs or DCHECKs.

## Build & test

```bash
# Build blink rendering tests:
autoninja -C out/Debug blink_tests

# Run layout tests:
third_party/blink/tools/run_web_tests.py \
  virtual/compositing/ \
  virtual/threaded/

# Run specific compositing tests:
third_party/blink/tools/run_web_tests.py \
  compositing/layer-creation/

# Run unit tests:
out/Debug/blink_unittests --gtest_filter="*Compositing*"
out/Debug/blink_unittests --gtest_filter="*Layout*"
```

## Key contacts & docs (internal)
- Read `docs/website/site/developers/design-documents/compositor-thread-architecture/` 
- Read `third_party/blink/renderer/core/paint/README.md`
- Read `cc/README.md`

## Reference files in this skill
- `references/property-trees.md` — deep dive on transform/clip/effect/scroll trees
- `references/renderingng-arch.md` — RenderingNG architecture and LayoutNG details
